document.getElementById('contactForm').addEventListener('submit', function (e) {
    e.preventDefault();
  
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const subject = document.getElementById('subject').value.trim();
    const message = document.getElementById('message').value.trim();
    const response = document.getElementById('formResponse');
  
    if (!name || !email || !subject || !message) {
      response.textContent = 'Please fill out all fields.';
      response.style.color = 'red';
      return;
    }
  
    // Simulate form submission (You can connect this to a backend later)
    response.textContent = 'Your message has been sent successfully!';
    response.style.color = 'green';
  
    // Clear the form
    document.getElementById('contactForm').reset();
  });
  