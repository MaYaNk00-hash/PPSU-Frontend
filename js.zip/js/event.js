function showEvent(eventId) {
    const events = document.querySelectorAll('.event');
    events.forEach(event => event.style.display = 'none');
    document.getElementById(eventId).style.display = 'block';
  }
  