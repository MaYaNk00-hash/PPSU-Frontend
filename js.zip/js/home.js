// Mobile Nav Toggle
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('nav-links');

hamburger?.addEventListener('click', () => {
  navLinks?.classList.toggle('show');
});

// Scroll Reveal Animation
window.addEventListener('scroll', () => {
  document.querySelectorAll('.reveal').forEach((section) => {
    const sectionTop = section.getBoundingClientRect().top;
    const triggerPoint = window.innerHeight * 0.85;
    if (sectionTop < triggerPoint) {
      section.classList.add('active');
    }
  });
});


// Contact Form Handler
const contactForm = document.querySelector('.contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Thanks for reaching out! We’ll get back to you shortly.');
  });
}

// Slideshow for Images and Videos
document.addEventListener("DOMContentLoaded", function () {
  // Image/Video Slideshow
  const slides = document.querySelectorAll('.slide');
  const dots = document.querySelectorAll('.dot');
  let currentSlide = 0;
  const slideInterval = 5000;
  

  function showSlide(index) {
    slides.forEach((slide, idx) => {
      slide.classList.toggle('active', idx === index);
      const video = slide.querySelector('video');
      if (video) {
        if (idx === index) {
          video.play();
        } else {
          video.pause();
          video.currentTime = 0;
        }
      }
    });

    dots.forEach((dot, idx) => {
      dot.classList.toggle('active', idx === index);
    });
  }

  function nextSlide() {
    currentSlide = (currentSlide + 1) % slides.length;
    showSlide(currentSlide);
  }

  if (slides.length > 0) {
    showSlide(currentSlide);
    setInterval(nextSlide, slideInterval);
  }

  dots.forEach((dot, idx) => {
    dot.addEventListener('click', () => {
      currentSlide = idx;
      showSlide(currentSlide);
    });
  });

  // Team Member Slideshow (4 visible at a time)
  const prevButton = document.getElementById('prev');
  const nextButton = document.getElementById('next');
  const slider = document.querySelector('.team-grid');
  const teamMembers = document.querySelectorAll('.team-grid .team-member');
  let currentTeamSlide = 0;
  const visibleMembers = 4; // The number of visible members at once
  const totalMembers = teamMembers.length;

  // Function to update the slider position
  const updateSliderPosition = () => {
    slider.style.transform = `translateX(-${(currentTeamSlide * 100) / visibleMembers}%)`;
  };

  // Show next slide (cycle through the remaining team members)
  const showNextTeamSlide = () => {
    currentTeamSlide = (currentTeamSlide + 1) % (totalMembers - visibleMembers + 1); // Loop through slides
    updateSliderPosition();
  };
  const maxSlides = Math.max(1, totalMembers - visibleMembers + 1);


  // Show previous slide (cycle backward)
  const showPrevTeamSlide = () => {
    currentTeamSlide = (currentTeamSlide - 1 + (totalMembers - visibleMembers + 1)) % (totalMembers - visibleMembers + 1);
    updateSliderPosition();
  };

  // Initialize the team slider
  const initTeamSlider = () => {
    updateSliderPosition();
  };

  // Set interval for automatic sliding every 5 seconds
  setInterval(showNextTeamSlide, 5000);

  // Event listeners for manual slide navigation
  nextButton?.addEventListener('click', showNextTeamSlide);
  prevButton?.addEventListener('click', showPrevTeamSlide);

  // Initialize the team slider
  initTeamSlider();
});


