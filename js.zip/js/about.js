// You can add interactivity here if needed
console.log("About page loaded.");
